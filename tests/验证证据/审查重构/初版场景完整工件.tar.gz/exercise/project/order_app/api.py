from .services import OrderService


class OrderAPI:
    def __init__(self, service: OrderService):
        self.service = service

    def cancel_order(self, order_id: str, actor_id: str) -> dict:
        order = self.service.cancel(order_id, actor_id)
        return {"id": order.id, "status": order.status}
