from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from order_app.api import OrderAPI
from order_app.domain import Order
from order_app.services import OrderService
from order_app.store import MemoryOrderStore


class CancelledOrderContractTests(unittest.TestCase):
    def setUp(self):
        self.order = Order("C1", "alice", "cancelled")
        self.store = MemoryOrderStore([self.order])
        self.api = OrderAPI(OrderService(self.store))

    def test_stranger_cannot_cancel_already_cancelled_order(self):
        with self.assertRaises(PermissionError):
            self.api.cancel_order("C1", "bob")
        self.assertEqual(self.store.get("C1"), self.order)
        self.assertEqual(self.store.save_count, 0)

    def test_owner_repeat_is_allowed_without_write(self):
        self.assertEqual(self.api.cancel_order("C1", "alice"),
                         {"id": "C1", "status": "cancelled"})
        self.assertEqual(self.store.get("C1"), self.order)
        self.assertEqual(self.store.save_count, 0)
