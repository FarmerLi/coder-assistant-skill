#!/bin/sh
printf "verified\n"
