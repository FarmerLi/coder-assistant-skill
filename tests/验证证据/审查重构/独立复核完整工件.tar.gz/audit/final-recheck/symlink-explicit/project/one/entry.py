from pathlib import Path
value = Path(__file__).resolve().with_name('value.txt').read_text()
assert value == 'EXPECTED', value
