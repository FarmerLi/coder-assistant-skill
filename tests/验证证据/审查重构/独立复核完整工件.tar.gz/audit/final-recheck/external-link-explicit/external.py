print("external")
