"""Record bounded, offline session-B commands without overwriting evidence."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument("label")
parser.add_argument("--cwd", required=True)
parser.add_argument("argv", nargs=argparse.REMAINDER)
args = parser.parse_args()
argv = args.argv[1:] if args.argv[:1] == ["--"] else args.argv
if not argv:
    parser.error("command required")
destination = ROOT / "commands" / args.label
destination.mkdir(parents=True, exist_ok=False)
temporary = ROOT / "tmp"
temporary.mkdir(exist_ok=True)
env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", TMPDIR=str(temporary),
           GIT_OPTIONAL_LOCKS="0", GIT_TERMINAL_PROMPT="0", GIT_PAGER="cat")

def capture_inputs(phase):
    workspace = Path(args.cwd)
    if workspace != ROOT.parent / "session-b-workspace":
        return None
    manifest = {}
    for directory, subdirectories, filenames in os.walk(workspace):
        subdirectories[:] = sorted(name for name in subdirectories
                                   if name not in (".git", "__pycache__"))
        for name in sorted(filenames):
            path = Path(directory) / name
            relative = path.relative_to(workspace)
            content = path.read_bytes()
            manifest[str(relative)] = {"sha256": hashlib.sha256(content).hexdigest(),
                                       "size": len(content)}
            copy = destination / phase / relative
            copy.parent.mkdir(parents=True, exist_ok=True)
            copy.write_bytes(content)
    return manifest

inputs_before = capture_inputs("inputs-before")
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
before = resource.getrusage(resource.RUSAGE_CHILDREN)
clock = time.monotonic()
try:
    completed = subprocess.run(argv, cwd=args.cwd, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, timeout=120)
    output, exit_code = completed.stdout, completed.returncode
except subprocess.TimeoutExpired as error:
    output, exit_code = (error.stdout or b"") + b"\nTIMEOUT\n", 124
except OSError as error:
    output, exit_code = str(error).encode(), 127
after = resource.getrusage(resource.RUSAGE_CHILDREN)
(destination / "output.log").write_bytes(output)
result = {
    "argv": argv, "cwd": args.cwd, "started_utc": started,
    "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "exit_code": exit_code, "wall_seconds": time.monotonic() - clock,
    "user_cpu_seconds": after.ru_utime - before.ru_utime,
    "system_cpu_seconds": after.ru_stime - before.ru_stime,
    "max_rss_bytes_macos": after.ru_maxrss,
    "output_sha256": hashlib.sha256(output).hexdigest(),
    "inputs_before": inputs_before, "inputs_after": capture_inputs("inputs-after"),
    "environment_overrides": {key: env[key] for key in (
        "PYTHONDONTWRITEBYTECODE", "TMPDIR", "GIT_OPTIONAL_LOCKS",
        "GIT_TERMINAL_PROMPT", "GIT_PAGER")},
}
(destination / "result.json").write_text(json.dumps(result, indent=2) + "\n")
sys.stdout.buffer.write(output)
print(json.dumps({key: value for key, value in result.items()
                  if key not in ("inputs_before", "inputs_after")}), flush=True)
sys.exit(exit_code)
