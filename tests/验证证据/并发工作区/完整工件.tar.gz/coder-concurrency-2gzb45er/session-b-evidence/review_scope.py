"""Verify session ownership and produce a shipping-only patch for the index."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

EVIDENCE = Path(__file__).resolve().parent
WORKSPACE = EVIDENCE.parent / "session-b-workspace"
BASELINE = EVIDENCE / "source-baseline-stable"
assert Path.cwd() == WORKSPACE
baseline = json.loads((BASELINE / "state.json").read_text())
before = (BASELINE / "files/money.py").read_text()
after = (WORKSPACE / "money.py").read_text()
assert before.split("def shipping_fee(")[0] == after.split("def shipping_fee(")[0]
before_ast, after_ast = ast.parse(before), ast.parse(after)
before_nodes = {node.name: node for node in before_ast.body if isinstance(node, ast.FunctionDef)}
after_nodes = {node.name: node for node in after_ast.body if isinstance(node, ast.FunctionDef)}
assert before_nodes.keys() == after_nodes.keys()
for name in ("subtotal", "discounted_total"):
    assert ast.dump(before_nodes[name]) == ast.dump(after_nodes[name]), name
before_nonfunctions = [ast.dump(node) for node in before_ast.body if not isinstance(node, ast.FunctionDef)]
after_nonfunctions = [ast.dump(node) for node in after_ast.body if not isinstance(node, ast.FunctionDef)]
assert before_nonfunctions == after_nonfunctions
for name, metadata in baseline["files"].items():
    if name != "money.py":
        assert hashlib.sha256((WORKSPACE / name).read_bytes()).hexdigest() == metadata["sha256"], name
assert not (WORKSPACE / ".git/objects/info/alternates").exists()
assert (WORKSPACE / ".git").resolve() != (EVIDENCE.parent / "source/.git").resolve()
patch = "".join(difflib.unified_diff(before.splitlines(keepends=True),
                                    after.splitlines(keepends=True),
                                    fromfile="a/money.py", tofile="b/money.py"))
assert "CURRENCY" not in patch
assert "subtotal" not in patch and "discounted_total" not in patch
(EVIDENCE / "shipping-money.patch").write_text(patch)
print(patch)
print("Verified: only shipping_fee changed; other exports and CNY preserved; draft unchanged.")
print("New shipping tests:")
print((WORKSPACE / "tests/test_shipping_fee.py").read_text())
