import datetime
import json
from pathlib import Path

EVIDENCE = Path(__file__).resolve().parent
WORKSPACE = EVIDENCE.parent / "session-b-workspace"
records = [(path.parent.name, json.loads(path.read_text()))
           for path in sorted((EVIDENCE / "commands").glob("*/result.json"))]

def disk(path):
    files = [item for item in path.rglob("*") if item.is_file()]
    return {"files": len(files), "logical_bytes": sum(item.stat().st_size for item in files),
            "allocated_bytes": sum(item.stat().st_blocks * 512 for item in files)}

metrics = {
    "measured_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "completed recorded commands 00 through 23; excludes report generation and model runtime",
    "command_count": len(records),
    "command_wall_seconds_sum": sum(item["wall_seconds"] for _, item in records),
    "user_cpu_seconds_sum": sum(item["user_cpu_seconds"] for _, item in records),
    "system_cpu_seconds_sum": sum(item["system_cpu_seconds"] for _, item in records),
    "max_child_rss_bytes": max(item["max_rss_bytes_macos"] for _, item in records),
    "workspace_disk": disk(WORKSPACE), "evidence_disk_at_measurement": disk(EVIDENCE),
    "subagents": 0, "services": 0, "ports": 0, "databases": 0,
    "network_requests": 0, "dependency_installs": 0,
    "nonzero_commands": [{"label": label, "exit_code": item["exit_code"]}
                         for label, item in records if item["exit_code"]],
}
(EVIDENCE / "resources.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2) + "\n")
peak = metrics["max_child_rss_bytes"] / 1024**2
total_bytes = metrics["workspace_disk"]["allocated_bytes"] + metrics["evidence_disk_at_measurement"]["allocated_bytes"]
cpu = metrics["user_cpu_seconds_sum"] + metrics["system_cpu_seconds_sum"]
report = f"""# 会话 B 交付报告

shipping_fee 已完成：金额小于 0 抛 ValueError；0—99 返回 10；100 及以上返回 0。没有实现 subtotal 或 discounted_total。自行审查未发现本次范围内未解决缺陷。

工作区：`{WORKSPACE}`；本地独占分支：`session-b-shipping`。
基线提交：`c7fb51a65399af2018e7e096d6c922d861d99e74`。
本次提交：`e71434413506f4993ac6a135717d67716e9fa6a7`。
完整补丁：`{EVIDENCE / 'shipping-fee.patch'}`；只修改 money.py 的 shipping_fee 函数体并新增 tests/test_shipping_fee.py，共 2 文件、24 行新增、1 行删除。

所有测试均在保留用户 `CURRENCY="CNY"` 的工作状态下运行。CNY 仍为未暂存修改，用户草稿仍未跟踪，二者均未混入本次提交。提交记录只包含本次运费差异；最终受测状态为上述提交叠加原有 CNY 修改。补丁在含原有 CNY 和草稿的固定副本中已实际重放并通过回归。

| 检查 | 实际结果 | 命令证据 |
| --- | --- | --- |
| 原有基线 `python3 -m unittest discover -s tests -v` | 1 测试通过，退出 0 | commands/07-baseline-tests |
| 运费 RED | 3 方法、8 个输入均因 NotImplementedError 报错，退出 1 | commands/09-shipping-red |
| 运费 GREEN | 3 测试方法通过，覆盖 0、1、99、100、101、10000、-1、-100，退出 0 | commands/10-shipping-green |
| 完整回归 | 4 测试通过，退出 0 | commands/11-full-regression |
| 差异及暂存检查 | 两次 diff --check 通过；其他函数 AST、公开导出和用户原内容保持一致 | commands/12-review-diff、13-scope-review、16-staged-check、17-staged-review |
| 交付补丁重放 | apply --check、apply、4 测试回归全部退出 0，重放结果与受测工作区一致 | commands/21-verify-delivered-patch；patch-verification-results.json |
| 最终状态绑定 | 最终文件 SHA-256 与完整回归输入一致 | commands/20-committed-state；workspace-final-state.json |
| 源仓库保护 | 文件内容、模式、HEAD、全部引用、index、config、Git 状态均与成功固定的基线一致 | commands/23-source-preservation；source-preservation.json |

实现与复用依据：`source-baseline-stable/files/项目说明.md:3-10` 规定由 money.py 的公开函数承担纯金额计算；语义搜索见 commands/08-reuse-search，没有现成运费规则或校验器可复用，因此直接在既有 shipping_fee 中最小实现，测试沿用标准库 unittest。生产修改位于工作区 money.py:24—28，测试位于 tests/test_shipping_fee.py:6—21。

原始命令、绝对工作目录、输出、退出码、时间与资源在每个 `commands/*/result.json` 和 `output.log`。RED、GREEN、回归及提交阶段另附运行前后的输入快照和 SHA-256。固定源输入保存于 source-baseline-stable；最终源状态保存于 source-final。初次扫描检测到 Git 元数据变化而退出 1，未作为输入使用；随后重试两次扫描一致才接受基线。初次失败未保存具体差异，无法判定变化来源。

资源统计范围为已记录命令 00—23：共 {len(records)} 条，累计执行墙钟 {metrics['command_wall_seconds_sum']:.3f} 秒、CPU {cpu:.3f} 秒，子进程最大 RSS {peak:.2f} MiB。统计时工作区及证据合计分配磁盘约 {total_bytes / 1024**2:.2f} MiB；详细字节数与文件数见 resources.json。统计不含模型推理时间、工具框架开销及报告生成；未取得主会话 token 或费用计量。

限制与整合：依用户要求未委派子 agent，未做独立上下文审查。使用 Python 3.14.2 和标准库；未启动常驻服务、占用端口、创建数据库或安装依赖；没有联网、推送、改全局配置或改 source 配置。只读 source 与指定技能，没有读取其他会话证据或工件。其他会话可能也修改 money.py，后续应由整合者按该函数差异显式应用本补丁，并对整合后的状态重新回归；本报告不宣称其他行为或跨会话整合已经完成。
"""
(EVIDENCE / "最终报告.md").write_text(report)
print(json.dumps(metrics, ensure_ascii=False, indent=2))
print(f"报告：{EVIDENCE / '最终报告.md'}")
