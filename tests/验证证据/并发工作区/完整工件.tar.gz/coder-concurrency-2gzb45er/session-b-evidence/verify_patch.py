"""Replay this session's deliverable on its frozen, user-modified input."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

EVIDENCE = Path(__file__).resolve().parent
destination = EVIDENCE / "patch-verification"
destination.mkdir(exist_ok=False)
baseline = EVIDENCE / "source-baseline-stable/files"
shutil.copytree(baseline, destination, dirs_exist_ok=True)
patch = EVIDENCE / "shipping-fee.patch"
commands = [
    ["git", "apply", "--check", str(patch)],
    ["git", "apply", str(patch)],
    [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
]
results = []
for command in commands:
    print(json.dumps({"argv": command, "cwd": str(destination)}), flush=True)
    result = subprocess.run(command, cwd=destination, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=30)
    print(result.stdout.decode(), end="", flush=True)
    print(f"exit_code={result.returncode}", flush=True)
    results.append({"argv": command, "cwd": str(destination),
                    "exit_code": result.returncode, "output": result.stdout.decode()})
    (EVIDENCE / "patch-verification-results.json").write_text(json.dumps({
        "patch_sha256": hashlib.sha256(patch.read_bytes()).hexdigest(),
        "commands": results,
    }, ensure_ascii=False, indent=2) + "\n")
    if result.returncode:
        sys.exit(result.returncode)
for name in ("money.py", "tests/test_shipping_fee.py", "用户草稿.txt"):
    assert (destination / name).read_bytes() == (EVIDENCE.parent / "session-b-workspace" / name).read_bytes(), name
assert (destination / "用户草稿.txt").read_bytes() == (baseline / "用户草稿.txt").read_bytes()
print("Patch replay matches tested workspace and preserves CNY plus user draft.")
