"""Read a stable source state; save only this session's source input."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys

SOURCE = Path("/private/tmp/coder-concurrency-2gzb45er/source")
destination = Path(sys.argv[1])
destination.mkdir(parents=True, exist_ok=False)

def git(*args):
    command = ["git", "--no-optional-locks", "-C", str(SOURCE), *args]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return {"argv": command, "exit_code": result.returncode,
            "stdout": result.stdout.decode(), "stderr": result.stderr.decode()}

def scan():
    contents, entries = {}, {}
    for directory, subdirectories, filenames in os.walk(SOURCE):
        subdirectories[:] = sorted(name for name in subdirectories if name != ".git")
        for name in sorted(filenames):
            path = Path(directory) / name
            key = str(path.relative_to(SOURCE))
            first = path.lstat()
            if not stat.S_ISREG(first.st_mode):
                raise RuntimeError(f"unexpected nonregular source input: {key}")
            content = path.read_bytes()
            second = path.lstat()
            assert (first.st_ino, first.st_mtime_ns, first.st_size, first.st_mode) == (
                second.st_ino, second.st_mtime_ns, second.st_size, second.st_mode), key
            contents[key] = content
            entries[key] = {"sha256": hashlib.sha256(content).hexdigest(),
                            "mode": stat.S_IMODE(first.st_mode), "size": len(content)}
    return contents, entries

def metadata():
    data = {"head": git("rev-parse", "HEAD"),
            "head_symbolic": git("symbolic-ref", "-q", "HEAD"),
            "refs": git("for-each-ref", "--format=%(refname) %(objectname)"),
            "status": git("status", "--porcelain=v2", "--branch", "--untracked-files=all"),
            "user_name": git("config", "--local", "--get", "user.name"),
            "user_email": git("config", "--local", "--get", "user.email")}
    data["git_files"] = {}
    for name in ("HEAD", "config", "index", "packed-refs"):
        path = SOURCE / ".git" / name
        data["git_files"][name] = hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None
    return data

first_meta = metadata()
contents, first_files = scan()
_, second_files = scan()
second_meta = metadata()
(destination / "observations.json").write_text(json.dumps({
    "first_files": first_files, "second_files": second_files,
    "first_git": first_meta, "second_git": second_meta,
}, ensure_ascii=False, indent=2) + "\n")
assert first_files == second_files, "source changed during snapshot"
assert first_meta == second_meta, "source Git state changed during snapshot"
for name, content in contents.items():
    path = destination / "files" / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
    path.chmod(first_files[name]["mode"])
state = {"source": str(SOURCE), "files": first_files, "git": first_meta}
(destination / "state.json").write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(state, ensure_ascii=False, indent=2))
