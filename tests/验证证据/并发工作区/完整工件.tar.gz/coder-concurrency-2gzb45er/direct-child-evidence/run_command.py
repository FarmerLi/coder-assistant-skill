from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/private/tmp/coder-concurrency-2gzb45er/implementation-child')
EVIDENCE = Path('/private/tmp/coder-concurrency-2gzb45er/direct-child-evidence')
label = sys.argv[1]
command = sys.argv[2:]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
env = os.environ.copy()
env['PYTHONDONTWRITEBYTECODE'] = '1'
fingerprints = {
    str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
    for p in sorted(ROOT.rglob('*'))
    if p.is_file() and '.git' not in p.relative_to(ROOT).parts
}
result = subprocess.run(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
for suffix, data in [('stdout.log', result.stdout), ('stderr.log', result.stderr)]:
    with (EVIDENCE / (label + '.' + suffix)).open('xb') as f:
        f.write(data)
metadata = {
    'command_argv': command,
    'cwd': str(ROOT),
    'started_utc': started,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'baseline': 'cb97eadc1422e4ae857d36b176ad926614eb8749',
    'source_files_sha256': fingerprints,
    'environment_override': {'PYTHONDONTWRITEBYTECODE': '1'},
    'exit_code': result.returncode,
}
with (EVIDENCE / (label + '.json')).open('x') as f:
    json.dump(metadata, f, ensure_ascii=False, indent=2)
    f.write('\n')
sys.stdout.buffer.write(result.stdout)
sys.stdout.buffer.flush()
sys.stderr.buffer.write(result.stderr)
sys.stderr.buffer.flush()
print('exit_code=' + str(result.returncode), flush=True)
sys.exit(result.returncode)
