from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(sys.argv.pop(1)).resolve()))
import money


class DirectChildAcceptance(unittest.TestCase):
    def test_composition_uses_public_helpers(self):
        items = [(60, 2)]
        with patch.object(money, 'subtotal', return_value=120) as subtotal, \
             patch.object(money, 'discounted_total', return_value=99) as discount, \
             patch.object(money, 'shipping_fee', return_value=10) as shipping:
            self.assertEqual(money.payable_total(items, 21), 109)
            subtotal.assert_called_once_with(items)
            discount.assert_called_once_with(120, 21)
            shipping.assert_called_once_with(99)

    def test_real_boundaries(self):
        for items, reduction, expected in (([], 0, 10), ([(60, 2)], 20, 100), ([(60, 2)], 21, 109), ([(10, 1)], 20, 10)):
            with self.subTest(items=items, reduction=reduction):
                self.assertEqual(money.payable_total(items, reduction), expected)
        for items, reduction in (([(-1, 1)], 0), ([(1, -1)], 0), ([], -1)):
            with self.subTest(items=items, reduction=reduction), self.assertRaises(ValueError):
                money.payable_total(items, reduction)


if __name__ == '__main__':
    unittest.main(verbosity=2)
