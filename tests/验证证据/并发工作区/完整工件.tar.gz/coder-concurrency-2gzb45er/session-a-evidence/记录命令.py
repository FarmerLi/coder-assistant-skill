#!/usr/bin/env python3
"""只在本会话证据目录保存有界本地命令、文件摘要和退出码。"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import sys
import time

ROOT = Path('/private/tmp/coder-concurrency-2gzb45er')
EVIDENCE = ROOT / 'session-a-evidence'


def manifest(directory):
    result = {}
    for path in sorted(directory.rglob('*')):
        relative = path.relative_to(directory)
        if '.git' in relative.parts or '__pycache__' in relative.parts:
            continue
        if path.is_file():
            data = path.read_bytes()
            result[str(relative)] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True)
    parser.add_argument('--cwd', required=True, type=Path)
    parser.add_argument('--expected', type=int, default=0)
    parser.add_argument('--identity', action='store_true')
    parser.add_argument('argv', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    argv = args.argv[1:] if args.argv[:1] == ['--'] else args.argv
    assert args.cwd.resolve().is_relative_to(ROOT.resolve())
    target = EVIDENCE / 'commands' / args.label
    target.parent.mkdir(exist_ok=True)
    assert not target.with_suffix('.json').exists(), '禁止覆盖命令证据'
    env = os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE='1', TMPDIR=str(EVIDENCE / 'tmp'), PIP_NO_INDEX='1', GIT_OPTIONAL_LOCKS='0')
    (EVIDENCE / 'tmp').mkdir(exist_ok=True)
    if args.identity:
        for key, variable in [('user.name', 'NAME'), ('user.email', 'EMAIL')]:
            value = subprocess.check_output(['git', '-C', str(ROOT / 'source'), 'config', '--local', '--get', key], text=True).strip()
            env['GIT_AUTHOR_' + variable] = value
            env['GIT_COMMITTER_' + variable] = value
    before = manifest(args.cwd)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    child_before = resource.getrusage(resource.RUSAGE_CHILDREN)
    start = time.monotonic()
    try:
        completed = subprocess.run(argv, cwd=args.cwd, env=env, capture_output=True, timeout=60)
        code, stdout, stderr = completed.returncode, completed.stdout, completed.stderr
    except subprocess.TimeoutExpired as error:
        code, stdout, stderr = 124, error.stdout or b'', (error.stderr or b'') + b'\nTIMEOUT (60 seconds)\n'
    elapsed = time.monotonic() - start
    child_after = resource.getrusage(resource.RUSAGE_CHILDREN)
    target.with_suffix('.stdout').write_bytes(stdout)
    target.with_suffix('.stderr').write_bytes(stderr)
    record = {
        'label': args.label, 'argv': argv, 'cwd': str(args.cwd), 'started_utc': started,
        'exit_code': code, 'expected_exit_code': args.expected, 'wall_seconds': elapsed,
        'child_user_cpu_seconds': child_after.ru_utime - child_before.ru_utime,
        'child_system_cpu_seconds': child_after.ru_stime - child_before.ru_stime,
        'child_maxrss_bytes_macos': child_after.ru_maxrss,
        'before_files': before, 'after_files': manifest(args.cwd),
        'stdout': stdout.decode(errors='replace'), 'stderr': stderr.decode(errors='replace'),
    }
    target.with_suffix('.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
    with (EVIDENCE / 'commands.jsonl').open('a') as stream:
        stream.write(json.dumps({key: value for key, value in record.items() if key not in ('before_files', 'after_files', 'stdout', 'stderr')}, ensure_ascii=False) + '\n')
    print(json.dumps({key: value for key, value in record.items() if key not in ('before_files', 'after_files')}, ensure_ascii=False, indent=2))
    return 0 if code == args.expected else 1


if __name__ == '__main__':
    sys.exit(main())
