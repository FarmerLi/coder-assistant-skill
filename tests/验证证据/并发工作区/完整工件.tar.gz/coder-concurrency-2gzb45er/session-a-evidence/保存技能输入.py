from pathlib import Path
import hashlib, json
r=Path('/private/tmp/coder-concurrency-2gzb45er/skill')
names=['SKILL.md', 'references/shared/并发工作区.md', 'references/shared/子代理协作.md', 'references/agents/实现.md', 'references/shared/input-and-evidence.md', 'references/shared/execution-contract.md', 'references/workflows/architecture.md', 'references/workflows/reuse.md', 'references/workflows/tdd.md', 'references/workflows/代码审查.md', 'references/workflows/verification.md', 'references/workflows/自动检查.md', 'references/shared/project-context.md']
records={}
for name in names:
 p=r/name
 content=p.read_bytes()
 records[name]={"sha256":hashlib.sha256(content).hexdigest(),"bytes":len(content)}
 print("\nFILE "+str(p)+"\n"+content.decode())
Path('/private/tmp/coder-concurrency-2gzb45er/session-a-evidence/skill-input-files.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+"\n")
