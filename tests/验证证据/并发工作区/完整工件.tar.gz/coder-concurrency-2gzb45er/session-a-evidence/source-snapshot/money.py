CURRENCY = "CNY"


def subtotal(items):
    """计算整数分金额的商品小计。"""
    raise NotImplementedError("待实现")


# 折扣独立于商品数量规则。
# 金额单位均为整数分。
# 折扣不能产生负数总额。


def discounted_total(amount, reduction):
    """应用固定金额折扣。"""
    raise NotImplementedError("待实现")


# 运费独立于商品小计计算。
# 门槛单位与其他金额一致。
# 不进行外部系统调用。


def shipping_fee(amount):
    """根据金额计算运费。"""
    raise NotImplementedError("待实现")
