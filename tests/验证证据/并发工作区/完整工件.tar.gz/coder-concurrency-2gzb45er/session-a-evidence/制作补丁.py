import argparse
import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path('/private/tmp/coder-concurrency-2gzb45er')
EVIDENCE = ROOT / 'session-a-evidence'
SNAPSHOT = EVIDENCE / 'source-snapshot'


def mask_functions(text, names):
    lines = text.splitlines(keepends=True)
    nodes = [node for node in ast.parse(text).body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert {node.name for node in nodes} == set(names)
    for node in sorted(nodes, key=lambda item: item.lineno, reverse=True):
        lines[node.lineno - 1:node.end_lineno] = [f'<owned-function:{node.name}>\n']
    return ''.join(lines)


parser = argparse.ArgumentParser()
parser.add_argument('--workspace', required=True, type=Path)
parser.add_argument('--name', required=True)
parser.add_argument('--functions', required=True, nargs='+')
parser.add_argument('--tests', required=True, nargs='+')
args = parser.parse_args()
assert args.workspace.resolve().is_relative_to(ROOT)
before = (SNAPSHOT / 'money.py').read_text()
after = (args.workspace / 'money.py').read_text()
assert mask_functions(before, args.functions) == mask_functions(after, args.functions), '函数归属外出现变化'
base_files = {str(path.relative_to(SNAPSHOT)): path for path in SNAPSHOT.rglob('*') if path.is_file()}
current_files = {str(path.relative_to(args.workspace)): path for path in args.workspace.rglob('*')
                 if path.is_file() and '.git' not in path.relative_to(args.workspace).parts}
assert set(current_files) == set(base_files) | set(args.tests), '出现范围外文件'
changes = []
for name in sorted(current_files):
    old = base_files[name].read_text() if name in base_files else ''
    new = current_files[name].read_text()
    if old == new:
        continue
    assert name in {'money.py', *args.tests}, f'意外修改 {name}'
    changes.append(''.join(difflib.unified_diff(old.splitlines(keepends=True), new.splitlines(keepends=True),
        fromfile='a/' + name if name in base_files else '/dev/null', tofile='b/' + name)))
patch = ''.join(changes)
target = EVIDENCE / (args.name + '.patch')
with target.open('x') as stream:
    stream.write(patch)
report = {'workspace': str(args.workspace), 'patch': str(target),
          'patch_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
          'owned_functions': args.functions, 'new_tests': args.tests,
          'outside_owned_functions_byte_identical': True,
          'inherited_user_files_unchanged': True, 'author': '主 agent；未发生子 agent 委派'}
(EVIDENCE / (args.name + '-scope.json')).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(report, ensure_ascii=False, indent=2))
print(patch)
