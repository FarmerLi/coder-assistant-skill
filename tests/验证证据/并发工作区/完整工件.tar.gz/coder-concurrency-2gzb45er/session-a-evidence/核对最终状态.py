import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path('/private/tmp/coder-concurrency-2gzb45er')
EVIDENCE = ROOT / 'session-a-evidence'
SOURCE = ROOT / 'source'
WORKSPACE = ROOT / 'session-a-workspace'


def manifest(directory):
    result = {}
    for path in sorted(directory.rglob('*')):
        if '.git' in path.relative_to(directory).parts or '__pycache__' in path.relative_to(directory).parts:
            continue
        if path.is_file():
            data = path.read_bytes()
            result[str(path.relative_to(directory))] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    return result


def git(directory, *args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(directory), *args], text=True)


initial = json.loads((EVIDENCE / 'source-initial-state.json').read_text())
source_now = {'files': manifest(SOURCE), 'head': git(SOURCE, 'rev-parse', 'HEAD').strip(),
              'refs': git(SOURCE, 'show-ref'),
              'status': git(SOURCE, 'status', '--porcelain=v2', '--untracked-files=all'),
              'diff': git(SOURCE, 'diff', '--binary'),
              'cached_diff': git(SOURCE, 'diff', '--cached', '--binary'),
              'git_metadata_sha256': {name: hashlib.sha256((SOURCE / '.git' / name).read_bytes()).hexdigest()
                                      for name in initial['git_metadata_sha256']}}
source_comparison = {key: source_now[key] == initial[key] for key in source_now}
(EVIDENCE / 'source-final-state.json').write_text(json.dumps(source_now, ensure_ascii=False, indent=2) + '\n')
assert all(source_comparison.values()), source_comparison

spec = importlib.util.spec_from_file_location('money_final_a', WORKSPACE / 'money.py')
money = importlib.util.module_from_spec(spec)
spec.loader.exec_module(money)
assert money.CURRENCY == 'CNY'
assert money.discounted_total(money.subtotal([(125, 3), (80, 2), (9, 4)]), 71) == 500
assert money.discounted_total(money.subtotal([]), 100) == 0

baseline_text = (EVIDENCE / 'source-snapshot' / 'money.py').read_text()
final_text = (WORKSPACE / 'money.py').read_text()
def function_text(text, name):
    node = next(node for node in ast.parse(text).body if isinstance(node, ast.FunctionDef) and node.name == name)
    return ''.join(text.splitlines(keepends=True)[node.lineno - 1:node.end_lineno])
assert function_text(baseline_text, 'shipping_fee') == function_text(final_text, 'shipping_fee')
assert manifest(EVIDENCE / 'patch-replay') == manifest(WORKSPACE)
regression = json.loads((EVIDENCE / 'commands' / '022-integrated-regression.json').read_text())
assert regression['exit_code'] == 0
assert regression['before_files'] == regression['after_files'] == manifest(WORKSPACE)

state = {'workspace': str(WORKSPACE), 'head': git(WORKSPACE, 'rev-parse', 'HEAD').strip(),
         'status': git(WORKSPACE, 'status', '--porcelain=v2', '--untracked-files=all'),
         'refs': git(WORKSPACE, 'show-ref', '--head'),
         'files': manifest(WORKSPACE), 'source_unchanged': source_comparison,
         'patch_replay_matches_final_files': True,
         'tested_state_matches_final_files': True,
         'currency': money.CURRENCY, 'shipping_fee_byte_identical_to_baseline': True,
         'composition_acceptance_checks_passed': 2,
         'baseline_commit': initial['head'], 'new_commits': [], 'delivery': 'patch',
         'patch': str(EVIDENCE / 'session-a-final.patch'),
         'patch_sha256': hashlib.sha256((EVIDENCE / 'session-a-final.patch').read_bytes()).hexdigest(),
         'subagents_created': 0, 'delegation_requirement_met': False,
         'independent_review_performed': False}
(EVIDENCE / 'final-state.json').write_text(json.dumps(state, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(state, ensure_ascii=False, indent=2))
