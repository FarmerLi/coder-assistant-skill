import datetime
import json
from pathlib import Path

ROOT = Path('/private/tmp/coder-concurrency-2gzb45er')
EVIDENCE = ROOT / 'session-a-evidence'
records = [json.loads(line) for line in (EVIDENCE / 'commands.jsonl').read_text().splitlines()]
final = json.loads((EVIDENCE / 'final-state.json').read_text())
test_runs = [record for record in records if 'unittest' in record['argv']]
resource_report = {
    'measured_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'recorded_command_count_before_reporting': len(records),
    'test_command_count': len(test_runs),
    'red_command_count': sum(record['exit_code'] == 1 for record in test_runs),
    'successful_test_command_count': sum(record['exit_code'] == 0 for record in test_runs),
    'commands_with_unexpected_exit': [record['label'] for record in records if record['exit_code'] != record['expected_exit_code']],
    'sum_recorded_command_wall_seconds': sum(record['wall_seconds'] for record in records),
    'sum_recorded_child_cpu_seconds': sum(record['child_user_cpu_seconds'] + record['child_system_cpu_seconds'] for record in records),
    'max_recorded_child_rss_bytes_macos': max(record['child_maxrss_bytes_macos'] for record in records),
    'measurement_scope': '只统计记录器执行的命令子进程，不包含主模型推理、工具宿主、前期只读调查或报告脚本；峰值为单命令记录的子进程峰值，非整机峰值',
    'implementation_workspaces': [str(ROOT / 'session-a-workspace'), str(ROOT / 'session-a-discount-workspace')],
    'local_git_repositories_created': 2, 'new_commits': 0, 'new_branches': 0,
    'subagents_created': 0, 'nested_agents_created': 0,
    'services': 0, 'ports': 0, 'databases': 0, 'dependencies_installed': 0,
    'network_operations': 0, 'pushes': 0, 'global_configuration_changes': 0,
    'token_usage': None, 'token_usage_limitation': '宿主未暴露本次模型 token 统计，不能估算为实测值',
    'disk_usage_command': 'commands/031-owned-disk-usage.json',
    'resource_cleanup': '无常驻进程；保留本会话工作区、快照和证据便于复核，没有清理其他会话资源',
}
(EVIDENCE / '资源使用.json').write_text(json.dumps(resource_report, ensure_ascii=False, indent=2) + '\n')
lines = [
    '# 会话 A 结果报告',
    '',
    'subtotal 和 discounted_total 的功能、真实 TDD、补丁整合与最终回归已完成。实际实现子 agent 委派未完成，因此本次演练未完全满足用户全部要求；两个切片均由主 agent 顺序完成，未执行独立审查。',
    '',
    '主工作区：`/private/tmp/coder-concurrency-2gzb45er/session-a-workspace`。折扣隔离工作区：`/private/tmp/coder-concurrency-2gzb45er/session-a-discount-workspace`。二者均为独立仓库，detached HEAD 固定在原始提交 `c7fb51a65399af2018e7e096d6c922d861d99e74`。',
    '',
    '交付补丁：`session-a-final.patch`，SHA-256：`' + final['patch_sha256'] + '`。相对于包含 CNY 和用户草稿的固定快照，只修改 money.py 的两个负责函数并新增两个测试文件。不创建提交或分支、不暂存或提交用户修改；两个工作区保留用户原有未提交状态。',
    '',
    '## 实现与验收',
    '',
    '| 范围 | 验证 | 原始证据 |',
    '| --- | --- | --- |',
    '| 原始基线 | 两个工作区分别运行，均为 1 个测试通过，退出码 0 | commands/007-main-baseline.*；commands/007-discount-baseline.* |',
    '| subtotal 正常路径 | 空序列、单项、多项、零值、大整数；5 个用例先因公开占位函数失败（退出 1），实现后通过（退出 0） | commands/010-subtotal-normal-red.*；011-subtotal-normal-green.* |',
    '| subtotal 负数拒绝 | 负价、负数量、双负、前有有效商品；补充用例后 9 个 subtest 断言失败（退出 1），实现验证后完整 10 个测试通过（退出 0） | commands/012-subtotal-validation-red.*；013-subtotal-green-regression.* |',
    '| discounted_total 正常路径 | 减免、零减免、相等、超额、零金额、大整数；6 个用例先因公开占位函数失败（退出 1），实现后通过（退出 0） | commands/014-discount-normal-red.*；015-discount-normal-green.* |',
    '| discounted_total 负数拒绝 | 负金额、负折扣、双负；补充用例后 5 个断言失败（退出 1），实现验证后完整 10 个测试通过（退出 0） | commands/016-discount-validation-red.*；017-discount-green-regression.* |',
    '| 明确整合 | 校验折扣补丁修改归属，再在主工作区检查和应用补丁 | discounted_total-scope.json；commands/020-discount-integration-check.*；021-discount-integration.* |',
    '| 最终回归 | python3 -m unittest discover -s tests -v，19 个测试全部通过，退出 0 | commands/022-integrated-regression.* |',
    '| 交付有效性 | 最终补丁从原始快照重放后的逐文件摘要与实测工作区完全一致；反向应用检查、空白检查通过 | commands/024-diff-check.*；026-final-patch-replay-check.* 至 029-final-source-and-workspace-integrity.* |',
    '',
    '没有必要的额外重构；保留简单整数循环与独立折扣规则。生产逻辑仅使用标准库和内置能力，不新增通用验证框架、不添加类型规则。主 agent 对最终差异的人工复核未发现本次范围内的实质缺陷；这不等同于独立审查。',
    '',
    '## 并发与用户状态',
    '',
    'source-initial-state.json 与 source-final-state.json 核对了完整源文件内容摘要、HEAD、已有分支引用、未提交和暂存差异、状态以及 .git/HEAD、config、index 摘要，全部相同。源工作区没有运行测试，也没有任何写入；没有读取其他会话的证据或工件。',
    '',
    '最终执行状态 CURRENCY 为 CNY；草稿及原有测试逐字保留。shipping_fee 的完整函数文本与原始快照逐字一致，仍为未实现占位；它在用户明确排除范围内，本次不验证其业务实现。最终回归输入摘要与交付文件摘要一致，另有 2 项小计后应用折扣的组合验收通过。',
    '',
    '## 资源与限制',
    '',
    f'记录的测试命令共 {len(test_runs)} 次，其中 4 次有效 RED；记录命令累计耗时 {resource_report["sum_recorded_command_wall_seconds"]:.3f} 秒，子进程 CPU 合计 {resource_report["sum_recorded_child_cpu_seconds"]:.3f} 秒，记录到的单命令子进程峰值内存 {resource_report["max_recorded_child_rss_bytes_macos"] / 1024**2:.2f} MiB。这些数据不包含模型推理和工具宿主开销。详见 资源使用.json 和磁盘使用命令原始输出。',
    '',
    '创建 2 个独立本地仓库，未创建提交、分支或子 agent；无服务、端口、数据库、依赖安装、联网、推送及全局配置变更。工作区和证据保留供复核，无本会话常驻后台进程。宿主未暴露模型 token 用量，未虚构统计。',
    '',
    '宿主工具目录没有适用的本地实现子 agent 创建、消息和等待接口；未以联网 CLI 或云端 agent 绕过离线限制。按照 ../skill/references/shared/子代理协作.md 的“无委派能力时主 agent 顺序完成，独立性不足如实披露”，已回退为主 agent 完成。实际委派和独立实现验证要求仍未满足。委派能力检查.json 保存能力核对结果，执行说明.md 保存完整原始材料索引、切片指令与拟委派输入，并明确未派发。',
    '',
    '所有关键执行的 argv、绝对 cwd、UTC 时间、原始 stdout/stderr、真实退出码、输入/输出文件摘要均位于 commands/；commands.jsonl 为索引，final-state.json 关联最终状态。实际测试的退出码 1 仅用于有效 RED，没有弱化断言、跳过失败或将记录器接受预期失败的退出 0 冒充测试通过。',
    '',
]
(EVIDENCE / '中文报告.md').write_text('\n'.join(lines))
print(json.dumps(resource_report, ensure_ascii=False, indent=2))
print('中文报告：' + str(EVIDENCE / '中文报告.md'))
