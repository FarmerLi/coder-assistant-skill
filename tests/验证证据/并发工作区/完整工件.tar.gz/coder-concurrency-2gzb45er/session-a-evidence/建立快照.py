import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/private/tmp/coder-concurrency-2gzb45er')
SOURCE = ROOT / 'source'
EVIDENCE = ROOT / 'session-a-evidence'


def read_state():
    files = {}
    for path in sorted(SOURCE.rglob('*')):
        if '.git' not in path.relative_to(SOURCE).parts and path.is_file():
            files[str(path.relative_to(SOURCE))] = path.read_bytes()
    def git(*args):
        return subprocess.check_output(['git', '--no-optional-locks', '-C', str(SOURCE), *args]).decode()
    metadata = {name: hashlib.sha256((SOURCE / '.git' / name).read_bytes()).hexdigest()
                for name in ['HEAD', 'config', 'index'] if (SOURCE / '.git' / name).is_file()}
    return files, {'head': git('rev-parse', 'HEAD').strip(),
                   'refs': git('show-ref'),
                   'status': git('status', '--porcelain=v2', '--untracked-files=all'),
                   'diff': git('diff', '--binary'),
                   'cached_diff': git('diff', '--cached', '--binary'),
                   'git_metadata_sha256': metadata}


before_files, before_meta = read_state()
snapshot = EVIDENCE / 'source-snapshot'
snapshot.mkdir()
for name, data in before_files.items():
    path = snapshot / name
    path.parent.mkdir(exist_ok=True, parents=True)
    path.write_bytes(data)
after_files, after_meta = read_state()
assert before_files == after_files and before_meta == after_meta, '源输入在快照期间改变，拒绝拼接不同时刻状态'
manifest = {name: {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)} for name, data in before_files.items()}
record = {'source': str(SOURCE), 'snapshot': str(snapshot), 'files': manifest, **before_meta,
          'stable_double_read': True, 'source_test_execution': False}
(EVIDENCE / 'source-initial-state.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(record, ensure_ascii=False, indent=2))
