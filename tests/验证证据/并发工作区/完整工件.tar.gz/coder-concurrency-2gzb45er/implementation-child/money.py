CURRENCY = "CNY"


def subtotal(items):
    """计算整数分金额的商品小计。"""
    total = 0
    for price, quantity in items:
        if price < 0 or quantity < 0:
            raise ValueError("单价和数量不能为负数")
        total += price * quantity
    return total


# 折扣独立于商品数量规则。
# 金额单位均为整数分。
# 折扣不能产生负数总额。


def discounted_total(amount, reduction):
    """应用固定金额折扣。"""
    if amount < 0 or reduction < 0:
        raise ValueError("金额和折扣不能为负数")
    return max(0, amount - reduction)


# 运费独立于商品小计计算。
# 门槛单位与其他金额一致。
# 不进行外部系统调用。


def shipping_fee(amount):
    """根据金额计算运费。"""
    if amount < 0:
        raise ValueError("金额不能为负数")
    return 0 if amount >= 100 else 10


def payable_total(items, reduction):
    """折后商品金额加运费。"""
    amount = subtotal(items)
    amount = discounted_total(amount, reduction)
    return amount + shipping_fee(amount)
