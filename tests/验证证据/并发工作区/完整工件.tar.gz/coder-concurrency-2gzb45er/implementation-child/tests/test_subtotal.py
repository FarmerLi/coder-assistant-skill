import unittest

from money import subtotal


class SubtotalTests(unittest.TestCase):
    def test_empty_sequence(self):
        self.assertEqual(subtotal([]), 0)

    def test_single_item(self):
        self.assertEqual(subtotal([(125, 3)]), 375)

    def test_sums_multiple_items(self):
        self.assertEqual(subtotal([(125, 3), (80, 2), (9, 4)]), 571)

    def test_zero_price_and_quantity(self):
        self.assertEqual(subtotal([(0, 5), (70, 0), (0, 0)]), 0)

    def test_large_integer_total_stays_exact(self):
        self.assertEqual(subtotal([(10**30, 3), (1, 1)]), 3 * 10**30 + 1)

    def test_rejects_negative_price(self):
        for quantity in (0, 1, 5):
            with self.subTest(quantity=quantity), self.assertRaises(ValueError):
                subtotal([(-1, quantity)])

    def test_rejects_negative_quantity(self):
        for price in (0, 1, 50):
            with self.subTest(price=price), self.assertRaises(ValueError):
                subtotal([(price, -1)])

    def test_rejects_two_negative_values(self):
        with self.assertRaises(ValueError):
            subtotal([(-10, -2)])

    def test_rejects_negative_values_after_valid_item(self):
        for invalid in ((-1, 0), (0, -1)):
            with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                subtotal([(125, 3), invalid])
