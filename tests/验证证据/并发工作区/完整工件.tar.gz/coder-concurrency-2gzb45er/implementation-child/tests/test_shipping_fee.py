import unittest

import money


class ShippingFeeTests(unittest.TestCase):
    def test_amount_below_threshold_costs_ten(self):
        for amount in (0, 1, 99):
            with self.subTest(amount=amount):
                self.assertEqual(money.shipping_fee(amount), 10)

    def test_amount_at_or_above_threshold_is_free(self):
        for amount in (100, 101, 10_000):
            with self.subTest(amount=amount):
                self.assertEqual(money.shipping_fee(amount), 0)

    def test_negative_amount_is_rejected(self):
        for amount in (-1, -100):
            with self.subTest(amount=amount):
                with self.assertRaises(ValueError):
                    money.shipping_fee(amount)
