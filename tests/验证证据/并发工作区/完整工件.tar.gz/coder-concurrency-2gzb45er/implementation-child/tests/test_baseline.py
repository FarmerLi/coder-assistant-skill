import unittest
import money

class BaselineTests(unittest.TestCase):
    def test_currency_code(self):
        self.assertEqual(len(money.CURRENCY), 3)
        self.assertTrue(money.CURRENCY.isupper())
