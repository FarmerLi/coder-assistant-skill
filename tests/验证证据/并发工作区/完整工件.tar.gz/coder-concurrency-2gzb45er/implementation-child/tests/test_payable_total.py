import unittest
from unittest.mock import Mock, call, patch

import money


class PayableTotalTests(unittest.TestCase):
    def test_sums_items_then_adds_shipping_after_discount(self):
        self.assertEqual(money.payable_total([(50, 2), (20, 3)], 70), 100)

    def test_shipping_threshold_uses_discounted_amount(self):
        for reduction, expected in ((19, 101), (20, 100), (21, 109)):
            with self.subTest(reduction=reduction):
                self.assertEqual(money.payable_total([(60, 2)], reduction), expected)

    def test_zero_reduction(self):
        self.assertEqual(money.payable_total([(25, 2)], 0), 60)

    def test_empty_items_still_pay_shipping(self):
        for reduction in (0, 20):
            with self.subTest(reduction=reduction):
                self.assertEqual(money.payable_total([], reduction), 10)

    def test_equal_or_excess_reduction_still_pays_shipping(self):
        for reduction in (50, 51):
            with self.subTest(reduction=reduction):
                self.assertEqual(money.payable_total([(25, 2)], reduction), 10)

    def test_zero_price_and_quantity(self):
        self.assertEqual(money.payable_total([(0, 5), (70, 0)], 0), 10)

    def test_large_integer_total_stays_exact(self):
        self.assertEqual(
            money.payable_total([(10**30, 1), (101, 1)], 10**30), 101
        )

    def test_preserves_existing_negative_input_errors(self):
        cases = (
            ([(-1, 0)], 0, "单价和数量不能为负数"),
            ([(0, -1)], 0, "单价和数量不能为负数"),
            ([(-10, -2)], 0, "单价和数量不能为负数"),
            ([(50, 2), (-1, 1)], 0, "单价和数量不能为负数"),
            ([(50, 2)], -1, "金额和折扣不能为负数"),
            ([], -1, "金额和折扣不能为负数"),
        )
        for items, reduction, message in cases:
            with self.subTest(items=items, reduction=reduction):
                with self.assertRaisesRegex(ValueError, message):
                    money.payable_total(items, reduction)

    def test_composes_existing_public_functions_in_order(self):
        items = [(60, 2)]
        calls = Mock()
        with (
            patch.object(money, "subtotal", return_value=150) as subtotal,
            patch.object(money, "discounted_total", return_value=80) as discounted,
            patch.object(money, "shipping_fee", return_value=7) as shipping,
        ):
            calls.attach_mock(subtotal, "subtotal")
            calls.attach_mock(discounted, "discounted_total")
            calls.attach_mock(shipping, "shipping_fee")
            self.assertEqual(money.payable_total(items, 20), 87)

        self.assertEqual(
            calls.mock_calls,
            [
                call.subtotal(items),
                call.discounted_total(150, 20),
                call.shipping_fee(80),
            ],
        )
