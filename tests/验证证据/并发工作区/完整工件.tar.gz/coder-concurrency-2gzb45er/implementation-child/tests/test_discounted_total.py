import unittest

from money import discounted_total


class DiscountedTotalTests(unittest.TestCase):
    def test_subtracts_reduction(self):
        self.assertEqual(discounted_total(250, 30), 220)

    def test_zero_reduction(self):
        self.assertEqual(discounted_total(250, 0), 250)

    def test_equal_reduction_returns_zero(self):
        self.assertEqual(discounted_total(250, 250), 0)

    def test_excess_reduction_returns_zero(self):
        self.assertEqual(discounted_total(250, 251), 0)

    def test_zero_amount(self):
        self.assertEqual(discounted_total(0, 0), 0)
        self.assertEqual(discounted_total(0, 10), 0)

    def test_large_integer_total_stays_exact(self):
        self.assertEqual(discounted_total(10**30 + 1, 10**30), 1)

    def test_rejects_negative_amount(self):
        for reduction in (0, 5):
            with self.subTest(reduction=reduction), self.assertRaises(ValueError):
                discounted_total(-1, reduction)

    def test_rejects_negative_reduction(self):
        for amount in (0, 5):
            with self.subTest(amount=amount), self.assertRaises(ValueError):
                discounted_total(amount, -1)

    def test_rejects_two_negative_values(self):
        with self.assertRaises(ValueError):
            discounted_total(-10, -2)
