import unittest

import app


class DoubleTests(unittest.TestCase):
    def test_positive_integers(self):
        for value, expected in (
            (1, 2),
            (7, 14),
            (12345678901234567890, 24691357802469135780),
        ):
            with self.subTest(value=value):
                self.assertEqual(app.double(value), expected)

    def test_negative_integers(self):
        for value, expected in ((-1, -2), (-7, -14)):
            with self.subTest(value=value):
                self.assertEqual(app.double(value), expected)

    def test_zero(self):
        self.assertEqual(app.double(0), 0)
