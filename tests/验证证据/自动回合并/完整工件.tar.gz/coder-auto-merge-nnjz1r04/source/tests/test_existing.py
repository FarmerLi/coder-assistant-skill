import unittest
import app

class ExistingTests(unittest.TestCase):
    def test_entry_exists(self):
        self.assertTrue(callable(app.double))
