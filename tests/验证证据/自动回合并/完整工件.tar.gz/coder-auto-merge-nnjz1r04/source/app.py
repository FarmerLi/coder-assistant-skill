def double(value):
    """返回整数的两倍。"""
    return value * 2
