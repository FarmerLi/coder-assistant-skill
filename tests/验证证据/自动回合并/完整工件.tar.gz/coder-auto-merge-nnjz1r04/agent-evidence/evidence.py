"""Record this fixture's actual commands and tested file states outside the project."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import time

ROOT = Path('/private/tmp/coder-auto-merge-nnjz1r04')
OUT = ROOT / 'agent-evidence'


def file_state(cwd):
    project = Path(cwd)
    paths = [project / 'app.py', project / '项目说明.md', project / '.gitignore']
    if (project / 'tests').exists():
        paths.extend(sorted((project / 'tests').rglob('*.py')))
    return {
        str(path.relative_to(project)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in paths if path.is_file()
    }


def run(label, argv, cwd=ROOT / 'source', expected=0):
    cwd = Path(cwd).resolve()
    cwd.relative_to(ROOT)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = file_state(cwd)
    tick = time.monotonic()
    env = os.environ.copy()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    result = subprocess.run(argv, cwd=cwd, env=env, text=True, capture_output=True)
    entry = {
        'label': label, 'started_utc': started, 'cwd': str(cwd),
        'argv': list(argv), 'command': shlex.join(argv),
        'exit_code': result.returncode, 'duration_seconds': time.monotonic() - tick,
        'stdout': result.stdout, 'stderr': result.stderr,
        'files_before': before, 'files_after': file_state(cwd),
        'PYTHONDONTWRITEBYTECODE': '1',
    }
    OUT.mkdir(exist_ok=True)
    target = OUT / (label + '.json')
    if target.exists():
        raise RuntimeError('Refuse to overwrite evidence: ' + str(target))
    target.write_text(json.dumps(entry, ensure_ascii=False, indent=2) + '\n')
    with (OUT / 'commands.jsonl').open('a') as stream:
        stream.write(json.dumps(entry, ensure_ascii=False) + '\n')
    (OUT / (label + '.log')).write_text(
        f'cwd: {cwd}\n$ {entry["command"]}\n'
        + result.stdout + result.stderr + f'\nexit_code: {result.returncode}\n')
    print(f'[{label}] cwd={cwd}\n$ {entry["command"]}', flush=True)
    print(result.stdout + result.stderr, end='', flush=True)
    print(f'exit_code={result.returncode}', flush=True)
    if expected is not None and result.returncode != expected:
        raise RuntimeError(f'{label}: expected {expected}, got {result.returncode}')
    return result


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
