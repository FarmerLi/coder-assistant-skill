import unittest
import app

class ExistingTests(unittest.TestCase):
    def test_double(self):
        self.assertEqual(app.double(2), 4)
