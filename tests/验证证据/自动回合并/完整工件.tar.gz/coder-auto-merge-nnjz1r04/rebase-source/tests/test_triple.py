import unittest

import app


class TripleTests(unittest.TestCase):
    def test_positive_integer(self):
        self.assertEqual(app.triple(7), 21)

    def test_negative_integer(self):
        self.assertEqual(app.triple(-4), -12)

    def test_zero(self):
        self.assertEqual(app.triple(0), 0)
