def double(value):
    return value * 2


def triple(value):
    """返回整数的三倍。"""
    return value * 3
