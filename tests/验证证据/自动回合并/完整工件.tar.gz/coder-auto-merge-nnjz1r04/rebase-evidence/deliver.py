"""本次实际执行的持锁本地交付代码；仅使用 Python 标准库和本地 Git。"""
from pathlib import Path
import datetime
import fcntl
import hashlib
import json
import os
import time

from record import run

BASE = Path('/private/tmp/coder-auto-merge-nnjz1r04')
EVIDENCE = BASE / 'rebase-evidence'
SESSION = BASE / 'session-triple'
TARGET = BASE / 'rebase-source'
CONTEXT = json.loads((EVIDENCE / 'task-context.json').read_text())
ORIGINAL = CONTEXT['original_task_commit']
COMMON = TARGET / '.git'
LOCK = COMMON / 'coder-assistant-merge.lock'


def save(name, value):
    with (EVIDENCE / name).open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def event(phase):
    value = {'phase': phase, 'pid': os.getpid(), 'lock_path': str(LOCK),
             'at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (EVIDENCE / 'lock-events.jsonl').open('a') as stream:
        stream.write(json.dumps(value, ensure_ascii=False) + '\n')
    print(json.dumps(value, ensure_ascii=False), flush=True)


def git(label, args, cwd=SESSION, required=True):
    return run(label, ['git', *args], cwd, required=required)


def text(label, args, cwd=SESSION):
    return git(label, args, cwd)['stdout'].strip()


def preflight(prefix, directory, branch):
    actual_branch = text(prefix + '-branch', ['symbolic-ref', '--short', 'HEAD'], directory)
    if actual_branch != branch:
        raise RuntimeError('Recorded branch changed: ' + actual_branch)
    if git(prefix + '-status', ['status', '--porcelain=v1', '--untracked-files=all'], directory)['stdout']:
        raise RuntimeError('Working tree is not clean: ' + str(directory))
    git_dir = Path(text(prefix + '-git-dir', ['rev-parse', '--absolute-git-dir'], directory))
    states = {name: (git_dir / name).exists() for name in
              ['MERGE_HEAD', 'CHERRY_PICK_HEAD', 'REVERT_HEAD', 'rebase-merge', 'rebase-apply', 'sequencer']}
    save(prefix + '-operation-state.json', states)
    if any(states.values()):
        raise RuntimeError('Git operation is already in progress')
    return text(prefix + '-head', ['rev-parse', 'HEAD'], directory)


save('delivery-source.json', {'path': str(Path(__file__).resolve()),
     'sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
     'argv': ['python3', str(Path(__file__).resolve())]})
# 保留锁文件本身，不删除它，以免其他会话锁住不同 inode。
with LOCK.open('a+') as lock_handle:
    event('waiting')
    deadline = time.monotonic() + 10
    while True:
        try:
            fcntl.flock(lock_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            if time.monotonic() >= deadline:
                raise RuntimeError('Merge-lock wait exceeded 10 seconds')
            time.sleep(0.1)
    event('acquired')
    try:
        actual_common = Path(text('locked-common-dir', ['rev-parse', '--git-common-dir'])).resolve()
        if actual_common != COMMON.resolve():
            raise RuntimeError('Unexpected shared Git directory')
        latest = preflight('locked-target', TARGET, 'delivery-target')
        session_head = preflight('locked-session', SESSION, 'session-triple')
        if session_head != ORIGINAL:
            raise RuntimeError('Session task commit changed')
        for label in ['green-tests', 'review-worktree-diff']:
            previous = json.loads((EVIDENCE / (label + '.json')).read_text())
            if previous['exit_code'] != 0:
                raise RuntimeError('Required pre-commit check did not pass')
        included = git('locked-already-included', ['merge-base', '--is-ancestor', ORIGINAL, latest], required=False)
        if included['exit_code'] not in (0, 1):
            raise RuntimeError('Cannot establish task ancestry')
        if included['exit_code'] == 0:
            candidate = latest
        else:
            replay = text('locked-replay-sequence', ['rev-list', '--reverse', latest + '..HEAD']).splitlines()
            if replay != [ORIGINAL]:
                raise RuntimeError('Replay sequence contains commits outside this task')
            git('locked-rebase', ['rebase', '--no-autostash', latest])
            candidate = text('locked-candidate-head', ['rev-parse', 'HEAD'])
            if text('locked-candidate-parent', ['rev-parse', candidate + '^']) != latest:
                raise RuntimeError('Rebased task does not directly follow the latest target')
        # 必须在目标更新之前落盘原提交与 rebase 后提交的对应关系。
        save('rebase-mapping.json', {'original_task_commit': ORIGINAL, 'rebased_task_commit': candidate,
             'latest_target_before_merge': latest, 'already_included': included['exit_code'] == 0})
        if included['exit_code'] == 1:
            paths = text('locked-candidate-paths', ['diff', '--name-only', latest, candidate, '--']).splitlines()
            if set(paths) != {'app.py', 'tests/test_triple.py'}:
                raise RuntimeError('Candidate changes exceed task scope')
            git('locked-candidate-diff', ['diff', latest, candidate, '--'])
            git('locked-candidate-diff-check', ['diff', '--check', latest, candidate, '--'])
            run('rebased-tests', ['python3', '-m', 'unittest', 'discover', '-s', 'tests', '-v'], SESSION)
        rechecked = preflight('before-ff-target', TARGET, 'delivery-target')
        if rechecked != latest:
            raise RuntimeError('Target changed during validation; no target update attempted')
        if included['exit_code'] == 1:
            git('locked-target-fast-forward', ['merge', '--ff-only', '--no-autostash', candidate], TARGET)
        save('delivery-progress.json', {'state': '已合并待检查', 'commit': candidate})
        refs = text('final-commit-refs', ['rev-parse', 'HEAD', 'refs/heads/delivery-target',
                    'refs/heads/session-triple'], TARGET).splitlines()
        if refs[0] != candidate or refs[1] != candidate:
            raise RuntimeError('Target commit does not match validated candidate')
        if included['exit_code'] == 1 and refs[2] != candidate:
            raise RuntimeError('Session branch does not match validated candidate')
        git('preserved-other-session-ancestry', ['merge-base', '--is-ancestor',
            CONTEXT['target_start_commit'], candidate], TARGET)
        git('preserved-other-files', ['diff', '--exit-code', CONTEXT['target_start_commit'], candidate,
            '--', 'notes.txt', 'tests/test_existing.py', '.gitignore', '项目说明.md'], TARGET)
        run('target-post-merge-tests', ['python3', '-m', 'unittest', 'discover', '-s', 'tests', '-v'], TARGET)
        for label, directory in [('final-target-status', TARGET), ('final-session-status', SESSION)]:
            status = git(label, ['status', '--porcelain=v1', '--branch', '--untracked-files=all'], directory)['stdout']
            if len(status.splitlines()) != 1:
                raise RuntimeError('Unexpected final worktree changes')
        git('final-delivery-history', ['log', '-4', '--oneline', '--decorate'], TARGET)
        save('delivery-result.json', {'state': '已合并且检查通过', 'target_worktree': str(TARGET),
             'target_branch': 'delivery-target', 'session_worktree': str(SESSION),
             'original_task_commit': ORIGINAL, 'rebased_task_commit': candidate,
             'previous_target_commit': latest, 'final_target_commit': refs[0],
             'post_merge_tests': '4 tests passed; exit 0', 'both_worktrees_clean': True,
             'other_session_commit_preserved': CONTEXT['target_start_commit'],
             'lock_held_through': '最新目标读取、rebase、候选测试、目标快进及合并后检查',
             'limitations': '按用户要求未联网、推送、修改配置、安装依赖或委派；仅本地标准库测试与主 agent 复核。'})
        event('delivery-complete')
    finally:
        event('releasing')
        fcntl.flock(lock_handle, fcntl.LOCK_UN)
        event('released')
