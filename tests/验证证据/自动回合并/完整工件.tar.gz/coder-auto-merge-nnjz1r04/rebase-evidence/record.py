from pathlib import Path
import datetime
import json
import subprocess
import sys

EVIDENCE = Path(__file__).resolve().parent

def run(label, argv, cwd, required=True):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=cwd, text=True, capture_output=True)
    record = {"label": label, "argv": argv, "cwd": str(cwd), "started_at": start,
              "finished_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "exit_code": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
    with (EVIDENCE / (label + ".json")).open("x") as stream:
        json.dump(record, stream, indent=2, ensure_ascii=False)
        stream.write("\n")
    print(json.dumps(record, ensure_ascii=False), flush=True)
    if required and result.returncode:
        raise RuntimeError("Command failed: " + label)
    return record

if __name__ == "__main__":
    record = run(sys.argv[1], sys.argv[3:], sys.argv[2], required=False)
    sys.exit(record["exit_code"])
