"""Compare the final workspace with its original snapshot and tested states."""

import difflib
import hashlib
import json
from pathlib import Path

EVIDENCE = Path(__file__).resolve().parent
PROJECT = EVIDENCE.parent / "project"
BASELINE = EVIDENCE / "01-baseline" / "project"


def manifest(root):
    return {
        str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(root.rglob("*"))
        if path.is_file() and "__pycache__" not in path.parts
    }


baseline = manifest(BASELINE)
current = manifest(PROJECT)
modified = sorted(name for name in baseline if current.get(name) != baseline[name])
added = sorted(set(current) - set(baseline))
removed = sorted(set(baseline) - set(current))
assert modified == ["order_app/api.py"], modified
assert added == ["tests/test_api.py"], added
assert removed == [], removed
diff = []
for name in modified + added:
    old = (BASELINE / name).read_text().splitlines(keepends=True) if name in baseline else []
    new = (PROJECT / name).read_text().splitlines(keepends=True)
    diff.extend(difflib.unified_diff(old, new, fromfile=f"baseline/{name}", tofile=f"final/{name}"))
(EVIDENCE / "final.diff").write_text("".join(diff))
verified_states = []
for label in ["03-api-green", "04-regression", "05-independent-regression", "06-independent-contract"]:
    result = json.loads((EVIDENCE / label / "result.json").read_text())
    tested = json.loads((EVIDENCE / label / "state.sha256.json").read_text())
    assert current == tested, f"Final code differs from {label}"
    assert result["exit_code"] == 0, f"Check not passing: {label}"
    verified_states.append(label)
summary = {
    "modified": modified,
    "added": added,
    "removed": removed,
    "final_state_matches_passed_checks": verified_states,
    "final_state_sha256": current,
    "diff": "final.diff",
}
(EVIDENCE / "final-review.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
