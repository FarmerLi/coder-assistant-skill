"""Independent acceptance checks; run from the reviewed project's directory."""

from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path.cwd()))

from order_app.api import OrderAPI
from order_app.domain import Order
from order_app.services import OrderService
from order_app.store import MemoryOrderStore


class PublicServiceOnly:
    __slots__ = ("calls", "result", "error")

    def __init__(self, result=None, error=None):
        self.calls = []
        self.result = result
        self.error = error

    def cancel(self, order_id, actor_id):
        self.calls.append((order_id, actor_id))
        if self.error is not None:
            raise self.error
        return self.result


class IndependentContractTests(unittest.TestCase):
    def test_real_service_state_and_actor_matrix(self):
        for status in ("open", "cancelled", "shipped"):
            for actor in ("Owner", "Other", "owner"):
                with self.subTest(status=status, actor=actor):
                    target = Order("Ab-19", "Owner", status)
                    neighbor = Order("ab-19", "Other", "open")
                    store = MemoryOrderStore([target, neighbor])
                    api = OrderAPI(OrderService(store))
                    if actor != "Owner":
                        with self.assertRaises(PermissionError):
                            api.cancel_order("Ab-19", actor)
                        expected, writes = target, 0
                    elif status == "shipped":
                        with self.assertRaises(ValueError):
                            api.cancel_order("Ab-19", actor)
                        expected, writes = target, 0
                    else:
                        self.assertEqual(
                            api.cancel_order("Ab-19", actor),
                            {"id": "Ab-19", "status": "cancelled"},
                        )
                        expected = Order("Ab-19", "Owner", "cancelled")
                        writes = 1 if status == "open" else 0
                    self.assertEqual(store.get("Ab-19"), expected)
                    self.assertEqual(store.get("ab-19"), neighbor)
                    self.assertEqual(store.save_count, writes)

    def test_repeated_calls_write_exactly_once(self):
        store = MemoryOrderStore([Order("r", "o")])
        api = OrderAPI(OrderService(store))
        for _ in range(5):
            self.assertEqual(api.cancel_order("r", "o"), {"id": "r", "status": "cancelled"})
        self.assertEqual(store.get("r"), Order("r", "o", "cancelled"))
        self.assertEqual(store.save_count, 1)

    def test_absent_and_case_mismatched_ids_preserve_all_data(self):
        original = [Order("ExactID", "Owner"), Order("Other", "Other", "shipped")]
        store = MemoryOrderStore(original)
        api = OrderAPI(OrderService(store))
        for missing in ("exactid", "EXACTID", "missing"):
            with self.subTest(order_id=missing):
                with self.assertRaises(KeyError):
                    api.cancel_order(missing, "Owner")
                self.assertEqual([store.get(o.id) for o in original], original)
                self.assertEqual(store.save_count, 0)

    def test_public_service_arguments_and_output_are_used(self):
        service = PublicServiceOnly(result=Order("ReturnedID", "Owner", "cancelled"))
        result = OrderAPI(service).cancel_order("MiXeD-ID", "MiXeD-Actor")
        self.assertEqual(service.calls, [("MiXeD-ID", "MiXeD-Actor")])
        self.assertEqual(result, {"id": "ReturnedID", "status": "cancelled"})

    def test_service_errors_propagate_without_wrapping(self):
        for error in (PermissionError("denied"), ValueError("state"), KeyError("absent")):
            with self.subTest(error_type=type(error).__name__):
                service = PublicServiceOnly(error=error)
                with self.assertRaises(type(error)) as caught:
                    OrderAPI(service).cancel_order("Target", "Actor")
                self.assertIs(caught.exception, error)
                self.assertEqual(service.calls, [("Target", "Actor")])


if __name__ == "__main__":
    unittest.main(verbosity=2)
