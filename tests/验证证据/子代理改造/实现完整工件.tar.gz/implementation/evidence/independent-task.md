# 独立验证委派原文

你是本次订单接口任务的独立验证者，使用不继承实现会话的新上下文。请按技能方法检查本次结果，不修改生产代码、既有测试或验收要求。只允许在指定 evidence 内写验证工件和报告；不要读取原始技能仓库的维护测试、历史实现或验证记录，也不要访问远端。不要再委派子 agent。

材料：
- 目标项目：`/private/tmp/coder-assistant-subagents-nxxgxsmo/implementation/project`。原始有效需求在该目录的 `项目说明.md`，请直接读取。
- 技能：`/private/tmp/coder-assistant-subagents-nxxgxsmo/skill-snapshot/SKILL.md`；请读取独立验证角色与关联方法 `references/agents/独立验证.md`、`references/shared/子代理协作.md`、`references/shared/input-and-evidence.md`、`references/workflows/verification.md`、`references/workflows/architecture.md`、`references/workflows/reuse.md`。
- 初始代码快照：`/private/tmp/coder-assistant-subagents-nxxgxsmo/implementation/evidence/01-baseline/project`。目标项目没有 Git 元数据，可用该快照检查差异。
- 工作区归属：实现者负责 `order_app/api.py` 和新增 `tests/test_api.py`。此时停止项目写入；验证期间不会改项目。验证者只能写 `/private/tmp/coder-assistant-subagents-nxxgxsmo/implementation/evidence/independent` 及以 `05-independent`、`06-independent` 开头的证据目录。

请分别进行代码审查和实际运行验收。直接读取原始需求、当前代码、相关测试与初始差异，判断范围、架构、复用、完整行为和错误路径。不要依据实现者自评或既往测试结论做判断；无需阅读 evidence 内其他工作笔记、历史输出或自评。可在 evidence/independent 生成补充验收脚本。

每次有意义的实际测试必须保存命令、实际原始输出、退出码和对应代码状态。可用现有工具 `python3 /private/tmp/coder-assistant-subagents-nxxgxsmo/implementation/evidence/run_check.py <唯一标签> <命令及参数...>`；该工具在运行前保存项目快照与 SHA-256、运行命令、原始合并输出、结果及环境。标签请使用 `05-independent-regression`、`06-independent-contract`。如新增补充脚本，将脚本内容和 SHA-256 也保存在 independent。不要补写未执行过的历史。

请把独立报告写入 `evidence/independent/report.md`，说明具体审查位置、实际检查、发现及严重性、未覆盖项、证据对应状态、是否产生持久改动、独立性限制。返回紧凑结论与证据绝对路径。全程中文交流。
