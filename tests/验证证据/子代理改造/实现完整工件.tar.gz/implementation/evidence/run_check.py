"""Run one real check and preserve its inputs, command, raw output, and result."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parent / "project"
label, *command = sys.argv[1:]
run_dir = ROOT / label
run_dir.mkdir()
snapshot = run_dir / "project"
snapshot.mkdir()
manifest = {}
for path in sorted(PROJECT.rglob("*")):
    relative = path.relative_to(PROJECT)
    if not path.is_file() or any(part in {"__pycache__", ".git"} for part in relative.parts):
        continue
    target = snapshot / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, target)
    manifest[str(relative)] = hashlib.sha256(path.read_bytes()).hexdigest()
(run_dir / "state.sha256.json").write_text(json.dumps(manifest, indent=2) + "\n")
metadata = {
    "command": command,
    "display_command": shlex.join(command),
    "cwd": str(PROJECT),
    "started_at": datetime.now(timezone.utc).isoformat(),
    "python": sys.version,
    "environment_overrides": {"PYTHONDONTWRITEBYTECODE": "1"},
    "state_manifest": "state.sha256.json",
    "state_snapshot": "project/",
    "raw_output": "output.txt",
}
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
process = subprocess.run(command, cwd=PROJECT, env=environment, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(run_dir / "output.txt").write_bytes(process.stdout)
metadata["finished_at"] = datetime.now(timezone.utc).isoformat()
metadata["exit_code"] = process.returncode
metadata["result"] = "PASS" if process.returncode == 0 else "FAIL"
(run_dir / "result.json").write_text(json.dumps(metadata, indent=2) + "\n")
sys.stdout.buffer.write(process.stdout)
print(f"\nEvidence: {run_dir}; exit code: {process.returncode}")
sys.exit(process.returncode)
