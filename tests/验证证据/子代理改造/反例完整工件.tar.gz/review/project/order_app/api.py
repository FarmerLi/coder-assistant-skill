from dataclasses import replace

from .services import OrderService


class OrderAPI:
    def __init__(self, service: OrderService):
        self.service = service

    def cancel_order(self, order_id: str, actor_id: str) -> dict:
        order = self.service._store.get(order_id)
        if order.owner != actor_id:
            raise PermissionError("只有订单所有者可以取消")
        if order.status != "cancelled":
            if order.status != "open":
                raise ValueError("当前订单状态不允许取消")
            order = replace(order, status="cancelled")
            self.service._store.save(order)
        return {"id": order.id, "status": order.status}
