"""独立验收：预期来自《项目说明.md》，仅读取目标项目。"""
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

PROJECT = Path('/private/tmp/coder-assistant-subagents-nxxgxsmo/review/project')
sys.path.insert(0, str(PROJECT))

from order_app.api import OrderAPI
from order_app.domain import Order
from order_app.services import OrderService
from order_app.store import MemoryOrderStore


class IndependentAcceptance(unittest.TestCase):
    def make_api(self, orders):
        store = MemoryOrderStore(orders)
        service = OrderService(store)
        return OrderAPI(service), service, store

    def test_owner_cancels_and_persists_exact_result(self):
        api, _, store = self.make_api([Order('A1', 'alice'), Order('B1', 'bob')])
        self.assertEqual(api.cancel_order('A1', 'alice'), {'id': 'A1', 'status': 'cancelled'})
        self.assertEqual(store.get('A1'), Order('A1', 'alice', 'cancelled'))
        self.assertEqual(store.get('B1'), Order('B1', 'bob'))
        self.assertEqual(store.save_count, 1)

    def test_repeat_returns_same_result_without_second_save(self):
        api, _, store = self.make_api([Order('A1', 'alice')])
        self.assertEqual(api.cancel_order('A1', 'alice'), {'id': 'A1', 'status': 'cancelled'})
        self.assertEqual(api.cancel_order('A1', 'alice'), {'id': 'A1', 'status': 'cancelled'})
        self.assertEqual(store.save_count, 1)

    def test_already_cancelled_owner_does_not_save(self):
        api, _, store = self.make_api([Order('A1', 'alice', 'cancelled')])
        self.assertEqual(api.cancel_order('A1', 'alice'), {'id': 'A1', 'status': 'cancelled'})
        self.assertEqual(store.save_count, 0)

    def test_stranger_is_rejected_for_every_existing_state(self):
        for status in ('open', 'cancelled', 'shipped'):
            with self.subTest(status=status):
                original = Order('A1', 'alice', status)
                api, _, store = self.make_api([original])
                with self.assertRaises(PermissionError):
                    api.cancel_order('A1', 'bob')
                self.assertEqual(store.get('A1'), original)
                self.assertEqual(store.save_count, 0)

    def test_owner_cannot_cancel_shipped_or_unknown_state(self):
        for status in ('shipped', 'closed'):
            with self.subTest(status=status):
                original = Order('A1', 'alice', status)
                api, _, store = self.make_api([original])
                with self.assertRaises(ValueError):
                    api.cancel_order('A1', 'alice')
                self.assertEqual(store.get('A1'), original)
                self.assertEqual(store.save_count, 0)

    def test_missing_order_raises_key_error_without_mutation(self):
        original = Order('A1', 'alice')
        api, _, store = self.make_api([original])
        with self.assertRaises(KeyError):
            api.cancel_order('missing', 'alice')
        self.assertEqual(store.get('A1'), original)
        self.assertEqual(store.save_count, 0)

    def test_case_mismatch_does_not_select_another_order(self):
        original = Order('A1', 'alice')
        api, _, store = self.make_api([original])
        with self.assertRaises(KeyError):
            api.cancel_order('a1', 'alice')
        self.assertEqual(store.get('A1'), original)
        self.assertEqual(store.save_count, 0)

    def test_distinct_case_ids_stay_distinct(self):
        api, _, store = self.make_api([Order('A1', 'alice'), Order('a1', 'bob')])
        self.assertEqual(api.cancel_order('a1', 'bob'), {'id': 'a1', 'status': 'cancelled'})
        self.assertEqual(store.get('A1'), Order('A1', 'alice'))
        self.assertEqual(store.get('a1'), Order('a1', 'bob', 'cancelled'))
        self.assertEqual(store.save_count, 1)

    def test_api_delegates_to_real_public_service_method(self):
        api, service, store = self.make_api([Order('A1', 'alice')])
        with patch.object(service, 'cancel', wraps=service.cancel) as public_cancel:
            result = api.cancel_order('A1', 'alice')
            self.assertEqual(result, {'id': 'A1', 'status': 'cancelled'})
            self.assertEqual(store.save_count, 1)
            public_cancel.assert_called_once_with('A1', 'alice')


if __name__ == '__main__':
    unittest.main(verbosity=2)
