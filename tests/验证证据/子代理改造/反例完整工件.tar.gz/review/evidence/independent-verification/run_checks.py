"""记录真实命令、实际输出、退出码；禁止写入项目或基线。"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys

ROOT = Path('/private/tmp/coder-assistant-subagents-nxxgxsmo/review')
EVIDENCE = Path(__file__).resolve().parent
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
CHECKS = [
    ('baseline-suite', ROOT / 'baseline', [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-v']),
    ('current-suite', ROOT / 'project', [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'tests', '-v']),
    ('independent-acceptance', ROOT / 'project', [sys.executable, '-B', str(EVIDENCE / 'test_independent_acceptance.py')]),
]


def run(check):
    name, cwd, argv = check
    result = subprocess.run(argv, cwd=cwd, env=ENV, text=True, capture_output=True)
    log = EVIDENCE / (name + '.log')
    log.write_text(f'CWD: {cwd}\nCOMMAND: {shlex.join(argv)}\nPYTHONDONTWRITEBYTECODE=1\nEXIT_CODE: {result.returncode}\n\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}')
    return {'name': name, 'cwd': str(cwd), 'argv': argv, 'exit_code': result.returncode, 'log': str(log), 'output': result.stdout + result.stderr}


with ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(run, CHECKS))
(EVIDENCE / 'checks-results.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
for result in results:
    print(json.dumps(result, ensure_ascii=False))

before = json.loads((EVIDENCE / 'input-manifest.json').read_text())['trees']
after = {}
for name in ['baseline', 'project']:
    after[name] = {
        str(p.relative_to(ROOT / name)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((ROOT / name).rglob('*'))
        if p.is_file() and '__pycache__' not in p.parts
    }
unchanged = before == after
(EVIDENCE / 'read-only-check.json').write_text(json.dumps({'source_trees_unchanged': unchanged, 'scope': 'all files except pre-existing __pycache__'}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'source_trees_unchanged': unchanged}))
