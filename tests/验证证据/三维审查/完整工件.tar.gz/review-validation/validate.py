import contextlib
import copy
import hashlib
import importlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent

@contextlib.contextmanager
def modules(path, names):
    sys.path.insert(0, str(path))
    for name in names:
        sys.modules.pop(name, None)
    try:
        yield {name: importlib.import_module(name) for name in names}
    finally:
        sys.path.pop(0)
        for name in names:
            sys.modules.pop(name, None)

def fingerprint():
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for case in ('case_a', 'case_b', 'case_c')
            for p in sorted((ROOT / case).rglob('*')) if p.is_file()}

def case_a():
    failures = 0
    for state in ('base', 'task', 'target', 'candidate'):
        with modules(ROOT / 'case_a' / state, ['cancel', 'pay', 'checkout']) as m:
            for entry in ('pay', 'checkout'):
                order = {'status': 'pending'}
                m[entry].__dict__[entry](order)
                ok = order['status'] == 'paid'
                print(json.dumps({'state': state, 'scenario': f'pending -> {entry}', 'pass': ok, 'actual': order}))
                failures += not ok
                order = {'status': 'pending'}
                m['cancel'].cancel(order)
                before = copy.deepcopy(order)
                rejected = False
                try:
                    m[entry].__dict__[entry](order)
                except ValueError:
                    rejected = True
                ok = rejected and order == before
                print(json.dumps({'state': state, 'scenario': f'cancel -> {entry}', 'pass': ok,
                                  'rejected': rejected, 'before': before, 'after': order}))
                failures += not ok
            if state in ('task', 'candidate'):
                order = {'status': 'pending'}
                m['cancel'].cancel(order)
                ok = order == {'status': 'pending', 'cancel_requested': True}
                print(json.dumps({'state': state, 'scenario': 'cancel registers without status change', 'pass': ok, 'actual': order}))
                failures += not ok
    return failures

def case_b():
    reviewed = ROOT / 'case_b' / 'reviewed'
    candidate = ROOT / 'case_b' / 'candidate'
    left = {str(p.relative_to(reviewed)): p.read_bytes() for p in reviewed.rglob('*') if p.is_file()}
    right = {str(p.relative_to(candidate)): p.read_bytes() for p in candidate.rglob('*') if p.is_file()}
    changed = sorted(k for k in left.keys() & right.keys() if left[k] != right[k])
    added, removed = sorted(right.keys() - left.keys()), sorted(left.keys() - right.keys())
    ok = not changed and added == ['notes.md'] and not removed
    print(json.dumps({'scenario': 'snapshot comparison', 'pass': ok, 'changed': changed, 'added': added, 'removed': removed}))
    print(json.dumps({'reused_historical_tests': [0, 42, 12345], 'rerun_here': False,
                      'reason': 'identical source; supplied requirements/environment/dependencies/rules unchanged',
                      'target_worktree_tests': 'NOT RUN; target not updated and merge not authorized'}))
    return int(not ok)

def case_c():
    failures = 0
    with modules(ROOT / 'case_c', ['service', 'public_api']) as m:
        report = {'owner': 'alice', 'content': 'private report'}
        for user in ('alice', 'bob'):
            result, error = None, None
            try:
                result = m['public_api'].get_report(user, report)
            except Exception as exc:
                error = type(exc).__name__
            ok = result == 'private report' and error is None if user == 'alice' else result != 'private report'
            print(json.dumps({'scenario': 'public report read', 'user': user, 'pass': ok, 'result': result, 'error': error}))
            failures += not ok
    print(json.dumps({'R2': 'reused intentional-behavior record; relevant source, requirement, callers unchanged per request', 'behavior_test_rerun': False}))
    return failures

if __name__ == '__main__':
    before = fingerprint()
    result = globals()[sys.argv[1]]()
    after = fingerprint()
    unchanged = before == after
    print(json.dumps({'fixture_unchanged': unchanged, 'snapshot_sha256': before}, sort_keys=True))
    sys.exit(1 if result or not unchanged else 0)
