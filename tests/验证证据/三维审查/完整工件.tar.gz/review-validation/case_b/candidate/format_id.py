def format_id(value):
    return str(value).zfill(4)
