def cancel(order):
    order["cancel_requested"] = True
