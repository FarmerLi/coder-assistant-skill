def pay(order):
    if order["status"] != "pending" or order.get("cancel_requested", False):
        raise ValueError("not payable")
    order["status"] = "paid"
