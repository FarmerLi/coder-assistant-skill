def checkout(order):
    if order["status"] != "pending":
        raise ValueError("not payable")
    order["status"] = "paid"
