from pay import pay
def checkout(order):
    pay(order)
