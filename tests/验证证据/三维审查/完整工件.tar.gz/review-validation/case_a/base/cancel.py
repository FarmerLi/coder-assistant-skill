def cancel(order):
    order["status"] = "cancelled"
