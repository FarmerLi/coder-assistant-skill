from pathlib import Path
import shutil, json, hashlib
root=Path('/tmp/coder-review-validation')
skill=root/'skill'
shutil.copytree(Path.cwd(),skill,ignore=shutil.ignore_patterns('.git','__pycache__','tests'),dirs_exist_ok=True)
base={'cancel.py': 'def cancel(order):\n    order["status"] = "cancelled"\n', 'pay.py':'def pay(order):\n    if order["status"] != "pending":\n        raise ValueError("not payable")\n    order["status"] = "paid"\n', 'checkout.py':'from pay import pay\ndef checkout(order):\n    pay(order)\n'}
task=dict(base); task['cancel.py']='def cancel(order):\n    order["cancel_requested"] = True\n'; task['pay.py']='def pay(order):\n    if order["status"] != "pending" or order.get("cancel_requested", False):\n        raise ValueError("not payable")\n    order["status"] = "paid"\n'
target=dict(base); target['checkout.py']='def checkout(order):\n    if order["status"] != "pending":\n        raise ValueError("not payable")\n    order["status"] = "paid"\n'
candidate=dict(task); candidate['checkout.py']=target['checkout.py']
for stage, files in [('base',base),('task',task),('target',target),('candidate',candidate)]:
    p=root/'case_a'/stage; p.mkdir(parents=True,exist_ok=True)
    for name,code in files.items(): (p/name).write_text(code)
(root/'case_a'/'request.md').write_text('''请使用提供的 coder-assistant 技能审查本地整合候选，给出能否进入目标更新的判断和证据。仅审查，不修改源代码、不提交或合并；可在临时目录运行验证。
有效要求：取消操作改为登记取消请求；一旦登记，所有支付入口必须拒绝支付且不得改变订单状态。checkout 是公开支付入口。base 是共同起点，task 是任务分支，target 是目标最新状态，candidate 是合并两侧差异的候选文件快照。原项目无并发处理要求。历史检查只有 task 上 cancel 后 pay 拒绝，以及 target 上 pending checkout 成功；尚未对 candidate 执行检查。
''')
p=root/'case_b'; p.mkdir(exist_ok=True)
for stage in ('reviewed','candidate'):
    (p/stage).mkdir(exist_ok=True); (p/stage/'format_id.py').write_text('def format_id(value):\n    return str(value).zfill(4)\n')
(p/'candidate'/'notes.md').write_text('团队会议改在周四。此文件不参与构建、运行或代码生成。\n')
(p/'request.md').write_text('''请使用提供的 coder-assistant 技能评估本轮还需哪些审查与检查。仅审查，不修改源代码或合并。有效需求：把非负整数格式化为至少四位的编号，保留更长编号。reviewed 的三维审查已完成：需求和系统一致性已检查，回归已检查，没有发现；0、42、12345 的行为测试已通过。该审查者使用新上下文。candidate 来自 rebase 后文件快照，目标仅新增 notes.md，任务提交哈希因重放变化；需求、环境、依赖、规则均未改变。项目要求快进后在目标工作区运行上述三个用例。尚未更新目标。
''')
p=root/'case_c'; p.mkdir(exist_ok=True)
(p/'service.py').write_text('def read_report(user, owner, content):\n    return content\n')
(p/'public_api.py').write_text('from service import read_report\ndef get_report(user, report):\n    return read_report(user, report["owner"], report["content"])\n')
(p/'format_id.py').write_text('def format_id(value):\n    return str(value).zfill(4)\n')
(p/'request.md').write_text('''请使用提供的 coder-assistant 技能审查本次新增 public_api.py，核对历史发现并输出处置与覆盖情况。仅审查，不修改源代码；可临时验证。有效需求：公开报告读取只允许所有者访问。兼容要求：format_id 接受非负整数，超过四位不截断。
历史记录 R1：service.py 无所有者判断曾被记为误报；当时仅有经过所有者校验的内部调用方，证据是旧调用链，失效条件是新增未校验调用方。本轮旧调用链仍在，另增加 public_api.py。
历史记录 R2：format_id 长于四位不截断，按上述兼容要求记为有意行为，相关代码、需求和调用方未变。
开发备注：public_api 不做身份判断更省事，先上线以后再补。没有来自业务或项目负责人的风险接受决定。
''')
files={str(p.relative_to(skill)):hashlib.sha256(p.read_bytes()).hexdigest() for p in skill.rglob('*') if p.is_file()}
(root/'skill-snapshot.json').write_text(json.dumps(files,ensure_ascii=False,indent=2)+'\n')
