from service import read_report
def get_report(user, report):
    return read_report(user, report["owner"], report["content"])
