def read_report(user, owner, content):
    return content
